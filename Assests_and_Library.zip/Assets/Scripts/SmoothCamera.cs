﻿using UnityEngine;
using System.Collections;

public class SmoothCamera : MonoBehaviour
{
    public Transform target;
    public float camFollowSpeed = 0.3f;
    public float offsetX = 0f;
    public float offsetY = 0f;
    public float offsetZ = -10f; 
    Camera cam; 


	// Use this for initialization
	void Start ()
    {
        cam = GetComponent<Camera>();
	}
	
	// Update is called once per frame
	void Update ()
    {
        //To do: Add scroll wheel funtion to adjust view in and out ie: change the 3f to a 
        //fixed range and is changed by the scroll wheel.

        //Maintains resolution of camera viewport despite resolution of screen.
        cam.orthographicSize = (Screen.height / 100f) / 2f;

        //If the target exsists, linear interpolate to the target(allows you to go from one number to another with a percentage of scale) 
        // (from, to, how far) 
        if (target)
        {
            //Move the camera to the target, and while keeping the camera -10 away from the scene.
            transform.position = Vector3.Lerp(transform.position, target.position, camFollowSpeed) + new Vector3(offsetX, offsetY, offsetZ);
        }
	}
}
