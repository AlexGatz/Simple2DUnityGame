﻿using UnityEngine;
using System.Collections;

public class Controller : MonoBehaviour
{
    Rigidbody2D rBody;
    Animator anim;
	public float setSpeed = 1f;

	// Use this for initialization
	void Start ()
    {
		//Grabs the componects assigns to the game object
        rBody = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
	}
	
	// Update is called once per frame
	void Update ()
    {

        Vector2 moveVector = new Vector2(Input.GetAxisRaw("Horizontal"),
            Input.GetAxisRaw("Vertical"));

        if (moveVector != Vector2.zero )
        {
            anim.SetBool("IsWalking", true);
            anim.SetFloat("InputX", moveVector.x);
            anim.SetFloat("InputY", moveVector.y);
        }
        else
        {
            anim.SetBool("IsWalking", false);
        }
		moveVector = moveVector * setSpeed;
		rBody.MovePosition (rBody.position + moveVector * Time.deltaTime);
	}
}
